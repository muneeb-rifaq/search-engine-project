import pandas as pd

def process_and_save_in_chunks(input_file, output_file, chunk_size, max_rows):
    """Process up to max_rows of the dataset in chunks and save to a new CSV."""
    chunk_count = 0
    total_rows_processed = 0  # Track the total number of rows processed

    for chunk in pd.read_csv(input_file, chunksize=chunk_size, encoding='utf-8', on_bad_lines='skip'):
        if total_rows_processed >= max_rows:
            break  # Stop processing if we've reached the max_rows limit
        
        chunk_count += 1
        print(f"Processing chunk {chunk_count}")

        # Calculate how many rows to write from this chunk
        rows_to_process = min(max_rows - total_rows_processed, len(chunk))
        if rows_to_process <= 0:
            break
        
        # Truncate the chunk to the rows that fit within the limit
        truncated_chunk = chunk.head(rows_to_process)

        # Append the truncated chunk to the output file
        truncated_chunk.to_csv(output_file, mode='a', header=(chunk_count == 1), index=False)

        # Update the total rows processed
        total_rows_processed += rows_to_process

    print(f"Data processing complete. Processed {total_rows_processed} rows across {chunk_count} chunks.")

# Path to your dataset
dataset_path = r"C:\Users\hp\Downloads\medium_articles\medium_articles.csv"
output_path = r"C:\Users\hp\Documents\GitHub\search-engine-project\processed_dataset.csv"

# Process the dataset with a maximum of 60,000 rows
process_and_save_in_chunks(dataset_path, output_path, max_rows=60000)