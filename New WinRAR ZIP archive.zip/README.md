# search engine project
 A search engine built using Flask and NextJS 
